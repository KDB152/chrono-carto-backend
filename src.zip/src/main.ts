// src/main.ts
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Activer CORS pour permettre au front-end de communiquer
  app.enableCors({
    origin: 'http://localhost:3000', // ton front-end
    credentials: true,               // si tu utilises les cookies
  });

  // Port du serveur backend
  await app.listen(3001);
  console.log('Backend running on http://localhost:3001');
}

bootstrap();
