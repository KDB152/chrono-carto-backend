// src/config/database.config.ts
import 'reflect-metadata';
import { DataSource } from 'typeorm';
import * as dotenv from 'dotenv';
dotenv.config();

// Import de toutes les entités
import { User, UserRole } from '../modules/users/entities/user.entity';
// import d'autres entités si tu en as
// import { Student } from '../modules/students/entities/student.entity';
// import { Class } from '../modules/classes/entities/class.entity';

export const databaseConfig = {
  type: 'mysql' as const, // ajoute "as const" pour TypeScript
  host: 'localhost',
  port: 3306,
  username: 'root',
  password: '',
  database: 'chrono_carto',
  entities: [User],
  migrations: ['src/database/migrations/*.ts'],
  synchronize: true,
  logging: true,
};
