// src/modules/auth/auth.service.ts
import { Injectable } from '@nestjs/common';
import { RegisterDto } from './dto/register.dto';
import { UsersService } from '../users/users.service';
import { StudentsService } from '../students/students.service';
import { ParentsService } from '../parents/parents.service';
import { UserRole } from '../users/entities/user.entity';

@Injectable()
export class AuthService {
  constructor(
    private usersService: UsersService,
    private studentsService: StudentsService,
    private parentsService: ParentsService,
  ) {}

  async register(registerDto: RegisterDto): Promise<{ message: string }> {
    const { firstName, lastName, email, password, phone, userType } = registerDto;

    // Convertir le string userType en enum UserRole
    let role: UserRole;
    switch (userType) {
      case 'student':
        role = UserRole.STUDENT;
        break;
      case 'parent':
        role = UserRole.PARENT;
        break;
      case 'teacher':
        role = UserRole.TEACHER;
        break;
      case 'admin':
        role = UserRole.ADMIN;
        break;
      default:
        role = UserRole.STUDENT; // valeur par défaut
    }

    const user = await this.usersService.createUser({
      email,
      password,
      first_name: firstName,
      last_name: lastName,
      role, // ✅ maintenant c'est un UserRole
    });

    if (role === UserRole.STUDENT) {
      await this.studentsService.createStudent(user.id, phone);
    } else if (role === UserRole.PARENT) {
      await this.parentsService.createParent(user.id, phone);
    }

    return { message: 'Inscription réussie. En attente de l\'approbation de l\'administrateur.' };
  }
}
