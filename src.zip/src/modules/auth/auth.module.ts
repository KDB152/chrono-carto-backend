// src/modules/auth/auth.module.ts
import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { UsersModule } from '../users/users.module';
import { StudentsModule } from '../students/students.module';
import { ParentsModule } from '../parents/parents.module';

@Module({
  imports: [UsersModule, StudentsModule, ParentsModule],
  providers: [AuthService],
  controllers: [AuthController],
})
export class AuthModule {}