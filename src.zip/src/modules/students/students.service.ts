// src/modules/students/students.service.ts
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Student } from './entities/student.entity';

@Injectable()
export class StudentsService {
  constructor(
    @InjectRepository(Student)
    private studentsRepository: Repository<Student>,
  ) {}

  async createStudent(userId: number, phone?: string): Promise<Student> {
    const student = this.studentsRepository.create({
      user_id: userId,
      phone_number: phone,
    });
    return this.studentsRepository.save(student);
  }
}