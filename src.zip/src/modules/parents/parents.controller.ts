import { Controller } from '@nestjs/common';

@Controller('parents')
export class ParentsController {}